package com.MRPBicycle.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.MRPBicycle.service.MaterialService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class mycontroller {

	ObjectMapper mapper = new ObjectMapper();

	@GetMapping("/test")
	public String test() {
		return "run success...!";
	}

	@Autowired
	private MaterialService materialService;

	@GetMapping("/MaterialsRequired")
	public String getRequiredMaterial(@RequestParam("noOfBicycles") int noOfBicycles) {
		String json = "";
		HashMap<String, Object> map2 = new HashMap<String, Object>();
		try {
			HashMap<String, Integer> result = materialService.MaterialRequiredforBicycle(noOfBicycles);
			String message = "Material requirements calculated successfully for " + noOfBicycles + " bicycles";
			
			map2.put("message",message);
			map2.put("StatusCode", 200);
			map2.put("Response", result);
			
			json = mapper.writeValueAsString(map2);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			map2.put("StatusCode", 500);
			map2.put("Response", "ERROR");
		}

		return json;
	}
	

	@GetMapping("/getMaxBicycles")
	public String getMaxBicycles() {
		String json = "";
		HashMap<String, Object> map2 = new HashMap<String, Object>();
		try {
			int maxBicycles = materialService.MaxBicycleOnInventory();
		String message = "Maximum number of bicycles that can be assembled with available inventory: " + maxBicycles;
			
			map2.put("message",message);
			map2.put("StatusCode", 200);
			map2.put("Response", maxBicycles);
			
			json = mapper.writeValueAsString(map2);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			map2.put("StatusCode", 500);
			map2.put("Response", "ERROR");
		}

		return json;
	}


}
