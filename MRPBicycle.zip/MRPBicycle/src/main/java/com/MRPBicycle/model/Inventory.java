package com.MRPBicycle.model;

import java.util.HashMap;

import org.springframework.stereotype.Component;

@Component
public class Inventory {
	HashMap<String,Integer> inventory;//= new HashMap<String,Integer>();
	
	public Inventory()
	{
		inventory = new HashMap<>();
		inventory.put("Seat", 50);
		inventory.put("Frame",50);
		inventory.put("BrakeSet", 100);
		inventory.put("Handlebar", 50);
		inventory.put("Wheels",100);
		inventory.put("Tires", 100);
		inventory.put("Chain", 50);
		inventory.put("CrankSet",50);
		inventory.put("Pedals", 100);
		// break parts
		inventory.put("BrakePaddle",100);
		inventory.put("BrakeCable", 100);
		inventory.put("LeverSet",100);
		inventory.put("BrakeShoes", 200);
		
	}
	public int getAvailableQuantity(String partName)
	{
		return inventory.getOrDefault(partName, 0);
		
	}

	

	
}
