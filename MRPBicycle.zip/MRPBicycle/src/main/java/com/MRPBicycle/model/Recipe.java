package com.MRPBicycle.model;

import java.util.HashMap;

import org.springframework.stereotype.Component;

@Component
public class Recipe {
	
	/*
	 * First Level – to assemble a Bicycle 1 seat, 1 frame, 2 brake sets, 1
	 * handlebar, 2 wheels, 2 tires, 1 chain, 1 crank set, 2 pedals are required.
	 * Second Level – to assemble a Brake set Each brake set assembly requires 1
	 * brake paddle, 1 brake cable, 1 set of Lever, and 2 brake Shoes.
	 * 
	 */
	
	HashMap<String,Integer> parts;//= new HashMap<String,Integer>();
	
	public Recipe()
	{
		  parts = new HashMap<>();
		parts.put("Seat", 1);
		parts.put("Frame",1);
		parts.put("BrakeSet", 2);
		parts.put("Handlebar", 1);
		parts.put("Wheels",2);
		parts.put("Tires", 2);
		parts.put("Chain", 1);
		parts.put("CrankSet",1);
		parts.put("Pedals", 2);
		// break parts
		parts.put("BrakePaddle",2);
		parts.put("BrakeCable", 2);
		parts.put("LeverSet",2);
		parts.put("BrakeShoes", 4);
		
	}
	public HashMap<String, Integer> getParts()
	{
		return parts;
	}
	
public int getQuantity(String partName)
{
	return parts.getOrDefault(partName,0);
	}
}
