package com.MRPBicycle.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MRPBicycle.model.Inventory;
import com.MRPBicycle.model.Recipe;

@Service
public class MaterialService {
	// recipe // inventory

	// @Autowired
	private Recipe recipe;
//	@Autowired
	private Inventory inventory;

	@Autowired
	public MaterialService(Recipe recipe, Inventory inventory) {
		this.recipe = recipe;
		this.inventory = inventory;

	}

	// 1. find required material for bicycles

	public HashMap<String, Integer> MaterialRequiredforBicycle(int TotNoOfBicycle) {
		HashMap<String, Integer> MaterialRequired = new HashMap<String, Integer>();
		// requiredm =partperbicyle * noBicycle

		System.out.println("1) Material Requirements for " + TotNoOfBicycle + " bicycles:");

		for (String part : recipe.getParts().keySet()) {
			int RequiredMaterialQuantity = recipe.getQuantity(part) * TotNoOfBicycle;
			int AvailableQuantity = inventory.getAvailableQuantity(part);
			int toBeOrdered = Math.max(0, RequiredMaterialQuantity - AvailableQuantity);
			MaterialRequired.put(part, toBeOrdered);

			System.out.println(part + ":");
			System.out.println("- Required Quantity: " + RequiredMaterialQuantity);
			System.out.println("- Available Quantity: " + AvailableQuantity);
			System.out.println(".................................................");
			System.out.println("2) final required quantity which is to be purchased from outside");
			System.out.println("- To Be Procured: " + toBeOrdered);
			System.out.println(".................................................");
		}
		return MaterialRequired;
	}

	public int MaxBicycleOnInventory() {
		// max bicycle from inventory Data
		// ava/req=possiBicycle

		int maxBicycle = Integer.MAX_VALUE;
		try {
			for (String part : recipe.getParts().keySet()) {
				int AvailableQuantity = inventory.getAvailableQuantity(part);
				int requiredQuantityPerBicycle = recipe.getQuantity(part);
				int possibleBicycleQuantity = AvailableQuantity / requiredQuantityPerBicycle;

				maxBicycle = Math.min(maxBicycle, possibleBicycleQuantity);
				
			}
			
			System.out.println("3) Maximum number of bicycles that can be assembled with available inventory: " + maxBicycle);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return maxBicycle;
	}

}
