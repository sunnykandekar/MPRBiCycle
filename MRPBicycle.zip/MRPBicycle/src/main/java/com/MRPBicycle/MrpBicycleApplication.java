package com.MRPBicycle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MrpBicycleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MrpBicycleApplication.class, args);
		
		System.out.println("MrpBicycleApplication Run succesfully...!");
	}
	


}
