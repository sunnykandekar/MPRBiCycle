package com.MRPBicycle.MRPBicycle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MrpBicycleApplicationTests {

	@Test
	void contextLoads() {
	}

}
